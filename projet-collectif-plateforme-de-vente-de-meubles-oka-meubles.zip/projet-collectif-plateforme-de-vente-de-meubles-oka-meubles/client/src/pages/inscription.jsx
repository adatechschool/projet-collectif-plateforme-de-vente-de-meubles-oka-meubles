import React, { useState } from "react";
import Navbar from "../components/navbar";
import Footer from "../components/footer";
import MeubleInscription from '../assets/meubleInscription1.jpg';
import { useHistory } from "react-router-dom";

const Inscription = () => {
    const history = useHistory();
    const [checked, setChecked] = useState(true);
    const [error, setError] = useState("");
    const handleSubmit = async (e) => {
        e.preventDefault();
        const form = e.target;
        const formData = new FormData(form);
        const email = formData.get("fmail");
        const password1 = formData.get("fpassword1");
        const password2 = formData.get("fpassword2");
    
        if (password1 !== password2) {
            setError("Passwords do not match");
            return;
        }
    
        const userData = {
            email: email,
            password: password1,
            isAdmin: false
        };
    
        try {
            const response = await fetch("/api/user", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                body: JSON.stringify(userData)
            });
    
            // Ensure the response is JSON
            const result = await response.json();
    
            if (response.ok) {
                history.push("/");
            } else {
                setError(result.error);
            }
        } catch (error) {
            setError("An error occurred. Please try again later.");
        }
    };
    

    const toggleCheck = () => {
        setChecked(!checked);
    };

    return (
        <>
            <Navbar />
            <div className="mt-40 flex">
                <div>
                    <img src={MeubleInscription} alt="" className="w-[600px] ml-[80px] mt-7" />
                </div>
                <div className="ml-20">
                    <h1 className="mb-5">I AM A NEW CUSTOMER</h1>
                    <p className="mb-5">Please fill in all the required fields.</p>
                    <h2 className="mb-5">PERSONAL INFORMATION</h2>
                    {error && <p className="error">{error}</p>}
                    <form onSubmit={handleSubmit} className="border border-black w-[700px] p-2 rounded-md">
                        <label htmlFor="fmail" className="ml-40">* Email: </label>
                        <input type="email" id="fmail" name="fmail" placeholder="Email" required className="border border-black ml-2 mb-2 w-[220px]"></input><br></br>
                        <label htmlFor="fpassword1" className="ml-9">* Create a password:</label>
                        <input type="password" id="fpassword1" name="fpassword1" placeholder="Enter a password" required className="border border-black ml-2 mb-2 w-[220px]"></input><br></br>
                        <label htmlFor="fpassword2">* Repeat your password:</label>
                        <input type="password" id="fpassword2" name="fpassword2" placeholder="Repeat your password" required className="border border-black ml-2 mb-2 w-[220px]"></input><br></br>
                        <input type="checkbox" checked={checked} onChange={toggleCheck} />
                        <label htmlFor="fcgu">I declare that I have read and accepted the general terms of use of the site</label><br></br>
                        <button disabled={!checked} className="ml-60 mt-4 bg-[#CED6C1] p-2 rounded-md hover:border border-[#242A21]">Submit</button>
                    </form>
                </div>
            </div>
            <Footer />
        </>
    );
};

export default Inscription;
