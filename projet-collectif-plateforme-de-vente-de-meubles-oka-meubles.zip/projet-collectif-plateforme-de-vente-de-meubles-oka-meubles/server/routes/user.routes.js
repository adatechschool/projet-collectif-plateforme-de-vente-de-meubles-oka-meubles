// server/routes/user.routes.js

const express = require("express");
const router = express.Router();
const UserController = require("../controllers/user.controller");

// Route for creating a new user
router.post("/user", UserController.createUser);

// Route for getting a user
router.post("/user/connect", UserController.getUser);

module.exports = router;
